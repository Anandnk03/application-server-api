#Login Page

- same sequelize formatter code line like Controller or Models,Migration and Routes

Communication Controller

- using filter drop down query like department or Module basic query
  if your project all get department and module using api

  using sql Scripts for Communication Controller

  - Get_Department
  - Get_Modules
  - PRC_GET_ALL_MACHINE
  - PRC_GET_PRODUCTBY_MACHINE

  Than we are using new scripts like gap reason controller

  - Get_4MTypes
  - PRC_GET_GAPREASONSLIST

Planing Controller.

- using the row query formatter
- no models
- using the row query in get sequelize us
- post and put method we are using the new sql Connotation. Because executing we are using the sequelize formatter but never using it
  post or put method in sequelize formatter..
  so we are the pool config system in our executing sequelize connotation ..

Planing Module Sql Scripts Name

- PRC_INSERT_PLAN_DETAILS
- PRC_GET_PLANDETAILS_RE
- PRC_UPDATE_PLANDETAILS
- PRC_UPDATE_DAILYSHIFTPLAN_STATUS

Gap Reason Controller

- using this controller hourly shift gap reason entry like hour by hour actual and plan diff entry the gap quantity add the gap reason

Gap reason Using Sql Scripts

- PRC_GET_GAPLIST
- PRC_INSERT_HOURLYSHIFT_GAPREASON
-

Rejection Controller

using the rejection screen get method and put or post method available ...
using raw query formatting...
using script ...

- PRC_GET_NC_LIST
- PRC_ADD_NC_QTY
- sql query using Select \* From E2M_NCReasons_Category_M
- PRC_Insert_NCReason
- PRC_Get_NCReasons_List
- PRC_Update_NCQty_Reason
