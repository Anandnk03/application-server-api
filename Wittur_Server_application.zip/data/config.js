// create configration objects
let CONFIG = {};

module.exports = CONFIG;
