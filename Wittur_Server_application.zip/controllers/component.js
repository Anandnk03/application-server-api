const moment = require('moment');
const { poolPromise, db } = require('../models/index');
const sql = require('mssql');


const addComponent= async (req, res) => {
  const {componentNumber,componentName,createBy} = req.body;

  console.log(req.body);

  try {
    const pool = await poolPromise;
    const componentData = await pool
      .request()
      .input('pIN_ComponentNumber',sql.NVarChar(255),componentNumber)
      .input('pIN_ComponentName',sql.NVarChar(255),componentName)
      .input('pIN_CreateBy',sql.VarChar(50),createBy)
      .execute(`PRC_Insert_ComponentData`);
   
    return res
      .status(200)
      .json({ msg: 'Component Add Successfully'});
  } catch (error) {
    console.log(error);
    res.status(500).json({ msg: 'Server Error' });
  }
};

// const addOperation = async(re,res)=>{

//     const{componentName,operationNumber,OperationName} = req.body;
//     console.log(req.body);

//     try {
//         const pool = await poolPromise;
//         const componentData = await pool
//           .request()
//           .input('pIN_ComponentId',sql.NVarChar(255),componentName)
//           .input('pIN_OperationName',sql.NVarChar(255),OperationName)
//           .input('pIN_OperationNumber',sql.NVarChar(50),operationNumber)
//           .execute(`PRC_Insert_Operation_Data`);
       
//         return res
//           .status(200)
//           .json({ msg: 'Operation Add Successfully'});
//       } catch (error) {
//         console.log(error);
//         res.status(500).json({ msg: 'Server Error' });
//       }
//     };



// const addOperation = async (req, res) => {
//   const { id } = req.params;
//   try {
//     const plan = await db.sequelize.query(`PRC_GET_PLANDETAILS_RE ${id}`);
//     res.status(200).json({ msg: 'Plan Founded..!', data: plan });
//   } catch (err) {
//     console.log(err);
//     res.status(500).json({ msg: 'Server Error' });
//   }
// };

// const update = async (req, res) => {
//   const { id, manpower, date, machineId } = req.body;

//   try {
//     const pool = await poolPromise;
//     const updatePlan = await pool
//       .request()
//       .input('pIN_MachineId', sql.Int, machineId)
//       .input('pIN_Plan', sql.Int, manpower)
//       .input('pIN_PlanID', sql.Int, id)
//       .input('pIN_ShiftDate', sql.Date, date)
//       .execute(`PRC_UPDATE_PLANDETAILS`);
//     const dataValues = updatePlan.recordset[0];
//     const newData = {
//       ...dataValues,
//       DATE: moment(dataValues.DATE).format('YYYY-MM-DD'),
//       STARTTIME: moment(dataValues.STARTTIME).format('YYYY-MM-DD HH:mm:ss'),
//     };
//     return res
//       .status(200)
//       .json({ msg: 'Plan Update SuccessFully ', data: newData });
//   } catch (error) {
//     console.log(error);
//     res.status(500).json({ msg: 'Server Error' });
//   }
// };



module.exports = {
  addComponent,

};
